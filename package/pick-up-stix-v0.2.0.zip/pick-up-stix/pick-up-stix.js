/**
 * This is your TypeScript entry file for Foundry VTT.
 * Register custom settings, sheets, and constants using the Foundry API.
 * Change this heading to be more descriptive to your module, or remove it.
 * Author: [your name]
 * Content License: [copyright and-or license] If using an existing system
 * 					you may want to put a (link to a) license or copyright
 * 					notice here (e.g. the OGL).
 * Software License: [your license] Put your desired license here, which
 * 					 determines how others may use and modify your module
 */
// Import TypeScript modules
import { registerSettings } from './module/settings.js';
import { preloadTemplates } from './module/preloadTemplates.js';
Hooks.on('getActorDirectoryFolderContext', () => {
    console.log('yeah!');
});
let socket;
export var SocketMessageType;
(function (SocketMessageType) {
    SocketMessageType[SocketMessageType["deleteToken"] = 0] = "deleteToken";
    SocketMessageType[SocketMessageType["updateToken"] = 1] = "updateToken";
    SocketMessageType[SocketMessageType["updateActor"] = 2] = "updateActor";
    SocketMessageType[SocketMessageType["createOwnedEntity"] = 3] = "createOwnedEntity";
})(SocketMessageType || (SocketMessageType = {}));
/**
 * Application class to display to select an item that the token is
 * associated with
 */
class SelectItemApplication extends Application {
    constructor(_token) {
        super({});
        this._token = _token;
        this._flags = {
            currency: {
                pp: 0,
                gp: 0,
                ep: 0,
                sp: 0,
                cp: 0
            },
            itemIds: [],
            canClose: true
        };
        console.log(`pick-up-stix | select item form | constructed with args:`);
        console.log(this._token);
        const itemFlags = this._token.getFlag('pick-up-stix', 'pick-up-stix');
        this._flags = Object.assign(Object.assign({}, this._flags), duplicate(itemFlags));
        console.log(`pick-up-stix | select item form | constructed with flags`);
        console.log(this._flags);
    }
    static get defaultOptions() {
        const options = super.defaultOptions;
        options.id = "pick-up-stix-selectItem";
        options.template = "modules/pick-up-stix/templates/select-item.html";
        options.width = 500;
        options.height = 'auto';
        options.minimizable = false;
        options.title = "Select an Item";
        options.resizable = true;
        return options;
    }
    get isContainer() {
        return this._flags.isContainer;
    }
    set isContainer(value) {
        this._flags.isContainer = value;
    }
    get imageContainerOpenPath() {
        return this._flags.imageContainerOpenPath;
    }
    set imageContainerOpenPath(value) {
        this._flags.imageContainerOpenPath = value;
    }
    get imageContainerClosedPath() {
        return this._flags.imageContainerClosedPath;
    }
    set imageContainerClosedPath(value) {
        this._flags.imageContainerClosedPath = value;
    }
    get selectionData() {
        return this._flags.itemIds;
    }
    set selectionData(value) {
        this._flags.itemIds = [
            ...value
        ];
    }
    get currency() {
        return this._flags.currency;
    }
    set currency(value) {
        this._flags.currency = Object.assign({}, value);
    }
    async setSelectionAmount(id, count) {
        let currItemData = this.selectionData.find(itemData => itemData.id === id);
        if (currItemData) {
            currItemData.count = count;
            console.log(`Previous value existed, setting ${currItemData.id} to count ${currItemData.count}`);
        }
        else {
            currItemData = { id, count: 1 };
            this.selectionData.push(currItemData);
            console.log(`Adding item ${currItemData.id} with count ${currItemData.count}`);
        }
        return currItemData;
    }
    activateListeners(html) {
        var _a;
        console.log(`pick-up-stix | SelectItemApplication | activateListeners called with args:`);
        console.log(html);
        super.activateListeners(this._html);
        this._html = html;
        Object.keys(this._flags.currency).forEach(k => {
            $(this._html).find(`.currency-wrapper [data-currency-type="${k}"]`).val(this._flags.currency[k]);
        });
        if (this.isContainer) {
            $(this._html).find(`#isContainerCheckBox`).prop('checked', true);
        }
        if (this._flags.canClose) {
            $(this._html).find(`#canCloseCheckBox`).prop('checked', true);
        }
        (_a = this.selectionData) === null || _a === void 0 ? void 0 : _a.forEach(itemData => {
            console.log(`pick-up-stix | selection from setup | setting item ${itemData.id} to active and count to ${itemData.count}`);
            const item = $(this._html).find(`[data-item-id="${itemData.id}"]`);
            if (itemData.count > 0) {
                item.addClass('active');
            }
            item.find('.count').val(itemData.count);
        });
        /**
         * Listen on the file input for when it's clicked. prevent the default dialog from
         * opening and open the Foundry FilePicker
         */
        $(this._html).find('input[type="file"]').click(e => {
            var _a;
            e.preventDefault();
            const openDialog = $(e.currentTarget).hasClass('open');
            const fp = new FilePicker({
                type: 'image',
                callback: path => {
                    console.log(`pick-up-stix | file picker picked | setting container image ${openDialog ? 'open' : 'closed'} path to ${path}`);
                    if (openDialog) {
                        this.imageContainerOpenPath = path;
                    }
                    else {
                        this.imageContainerClosedPath = path;
                    }
                    this.render();
                }
            }).browse((_a = (openDialog ? this.imageContainerOpenPath : this.imageContainerClosedPath)) !== null && _a !== void 0 ? _a : '');
        });
        /**
         * Listen for the container checkbox change event
         */
        $(this._html).find('#isContainerCheckBox').change(async (e) => {
            console.log(`pick-up-stix | select form | file input check box changed`);
            this.isContainer = !this.isContainer;
            this.render();
        });
        if (this.isContainer) {
            /**
             * Listen for if the can close checkbox is changed
             */
            $(this._html).find('#canCloseCheckBox').change(async (e) => {
                console.log(`pick-up-stix | SelectItemApplication | canCloseCheckBox changed`);
                this._flags.canClose = !this._flags.canClose;
            });
        }
        /**
         * Listen for the change event on the count input
         */
        $(this._html).find('.item .count').change(async (e) => {
            const count = +$(e.currentTarget).val();
            const id = $(e.currentTarget).parent().attr('data-item-id');
            console.log(`pick-up-stix | selection from count input changed | Setting item ${id} to count ${count}`);
            if (count === 0) {
                $(this._html).find(`[data-item-id="${id}"]`).removeClass('active');
            }
            else if (count > 0) {
                $(this._html).find(`[data-item-id="${id}"]`).addClass('active');
            }
            await this.setSelectionAmount(id, count);
        });
        /**
         * listen for currency input changes
         */
        $(this._html).find('.currency-wrapper .currency-input').change(e => {
            console.log(`pick-up-stix | select item form | currency input changed with args:`);
            console.log(e);
            const currency = $(e.currentTarget).attr('data-currency-type');
            const amount = $(e.currentTarget).val();
            console.log(this._flags);
            this._flags.currency[currency] = amount;
            console.log(this._flags.currency);
        });
        /**
         * Listen for clicks on each item's image and increment the item's count by one
         */
        $(this._html).find('.item img').click(async (e) => {
            const item = $(e.currentTarget).parent();
            const itemId = item.attr('data-item-id');
            let currItemData = this.selectionData.find(itemData => itemData.id === itemId);
            currItemData = await this.setSelectionAmount(itemId, currItemData ? currItemData.count + 1 : 1);
            item.find('.count').val(currItemData[1]);
            console.log(`pick-up-stix | selection form image clicked | setting item ${itemId} to count ${currItemData.count}`);
            item.addClass('active');
            this.render();
        });
    }
    getData() {
        return {
            options: this.options,
            object: {
                items: duplicate(game.items.entities.filter(i => !['class', 'spell', 'feat'].includes(i.type))),
                isContainer: this.isContainer,
                imageContainerOpenPath: this.imageContainerOpenPath,
                imageContainerClosedPath: this.imageContainerClosedPath
            }
        };
    }
    async close() {
        const flags = Object.assign({}, this._flags);
        const update = {
            img: flags.isOpen ? flags.imageContainerOpenPath : flags.imageContainerClosedPath,
            flags: {
                'pick-up-stix': {
                    'pick-up-stix': Object.assign({}, flags)
                }
            }
        };
        await this._token.update(update);
        // await this._token.setFlag('pick-up-stix', 'pick-up-stix', flags);
        super.close();
    }
}
/* ------------------------------------ */
/* Initialize module					*/
/* ------------------------------------ */
Hooks.once('init', async function () {
    console.log('pick-up-stix | init Hook');
    CONFIG.debug.hooks = true;
    console.log(game.data.version);
    // Assign custom classes and constants here
    // Register custom module settings
    registerSettings();
    // Preload Handlebars templates
    await preloadTemplates();
    const coreVersion = game.data.version;
    if (/0.7.\d/.test(coreVersion)) {
        Hooks.on('dropCanvasData', async (canvas, dropData) => {
            console.log(`pick-up-stix | dropCanvasData | called with args:`);
            console.log(canvas, dropData);
            if (dropData.type === "Item") {
                handleDropItem(dropData);
            }
        });
    }
    else {
        Canvas.prototype._onDrop = handleOnDrop;
    }
    // Register custom sheets (if any)
});
/* ------------------------------------ */
/* Setup module							*/
/* ------------------------------------ */
Hooks.once('setup', function () {
    // Do anything after initialization but before
    // ready
    console.log(`pick-up-stix | setup Hook`);
});
Hooks.once('canvasReady', function () {
    console.log(`pick-up-stix | Canvas ready, adding PickUpStixItemLayer`);
});
/* ------------------------------------ */
/* When ready													  */
/* ------------------------------------ */
Hooks.once('ready', function () {
    var _a, _b;
    // Do anything once the module is ready
    console.log(`pick-up-stix | ready hook`);
    (_b = (_a = canvas === null || canvas === void 0 ? void 0 : canvas.tokens) === null || _a === void 0 ? void 0 : _a.placeables) === null || _b === void 0 ? void 0 : _b.forEach(async (p) => {
        const data = p.getFlag('pick-up-stix', 'pick-up-stix');
        if (data) {
            console.log(`pick-up-stix | ready hook | found token ${p.id} with itemIds`);
            p.mouseInteractionManager = setupMouseManager.bind(p)();
        }
    });
    socket = game.socket;
    socket.on('module.pick-up-stix', async (msg) => {
        console.log(`pick-up-stix | socket.on | received socket message with args:`);
        console.log(msg);
        if (msg.sender === game.user.id) {
            console.log(`pick-up-stix | receieved socket message | i sent this, ignoring`);
            return;
        }
        const firstGm = game.users.find((u) => u.isGM && u.active);
        if (firstGm && game.user !== firstGm) {
            return;
        }
        let actor;
        let token;
        switch (msg.type) {
            case SocketMessageType.updateActor:
                actor = game.actors.get(msg.data.actorId);
                await actor.update(msg.data.updates);
                break;
            case SocketMessageType.deleteToken:
                await canvas.scene.deleteEmbeddedEntity('Token', msg.data);
                break;
            case SocketMessageType.updateToken:
                token = canvas.tokens.get(msg.data.tokenId);
                await token.update(msg.data.updates);
                break;
            case SocketMessageType.createOwnedEntity:
                actor = game.actors.get(msg.data.actorId);
                await actor.createOwnedItem(msg.data.items);
                break;
        }
    });
    socket.emit('module.pick-up-stix', 'yep you got it!');
});
Hooks.on('renderTokenHUD', (hud, hudHtml, data) => {
    var _a, _b, _c;
    if (!data.isGM) {
        console.log(`pick-up-stix | renderTokenHUD | user is not a gm, don't change HUD`);
        return;
    }
    if (data.actorId) {
        console.log(`pick-up-stix | renderTokenHUD | token has an actor associated with it, dont' change HUD`);
        return;
    }
    const flags = (_b = (_a = data.flags) === null || _a === void 0 ? void 0 : _a['pick-up-stix']) === null || _b === void 0 ? void 0 : _b['pick-up-stix'];
    const containerDiv = document.createElement('div');
    containerDiv.style.display = 'flex';
    containerDiv.style.flexDirection = 'row';
    // create the control icon div and add it to the container div
    const controlIconDiv = document.createElement('div');
    controlIconDiv.className = 'control-icon';
    const controlIconImg = document.createElement('img');
    controlIconImg.src = ((_c = flags === null || flags === void 0 ? void 0 : flags['itemIds']) === null || _c === void 0 ? void 0 : _c.length) ? 'modules/pick-up-stix/assets/pick-up-stix-icon-white.svg'
        : 'modules/pick-up-stix/assets/pick-up-stix-icon-black.svg';
    controlIconImg.className = "item-pick-up";
    controlIconDiv.appendChild(controlIconImg);
    controlIconDiv.addEventListener('mousedown', displayItemContainerApplication(hud, controlIconImg, data));
    containerDiv.appendChild(controlIconDiv);
    // if the item is a container then add the lock icon
    if (flags === null || flags === void 0 ? void 0 : flags.isContainer) {
        const lockDiv = document.createElement('div');
        lockDiv.style.marginRight = '10px';
        lockDiv.className = 'control-icon';
        const lockImg = document.createElement('img');
        lockImg.src = (flags === null || flags === void 0 ? void 0 : flags['isLocked']) ? 'modules/pick-up-stix/assets/lock-white.svg'
            : 'modules/pick-up-stix/assets/lock-black.svg';
        lockDiv.appendChild(lockImg);
        lockDiv.addEventListener('mousedown', toggleLocked(data));
        containerDiv.prepend(lockDiv);
    }
    // add the container to the hud
    $(hudHtml.children('div')[0]).prepend(containerDiv);
});
function toggleLocked(data) {
    return async () => {
        const token = canvas.tokens.get(data._id);
        const isLocked = token.getFlag('pick-up-stix', 'pick-up-stix.isLocked');
        await token.setFlag('pick-up-stix', 'pick-up-stix.isLocked', !isLocked);
    };
}
Hooks.on('updateToken', (scene, tokenData, tokenFlags, userId) => {
    var _a, _b;
    console.log(`pick-up-stix | updateToken`);
    const token = (_b = (_a = canvas === null || canvas === void 0 ? void 0 : canvas.tokens) === null || _a === void 0 ? void 0 : _a.placeables) === null || _b === void 0 ? void 0 : _b.find((p) => p.id === tokenData._id);
    const flags = token.getFlag('pick-up-stix', 'pick-up-stix');
    if (flags) {
        token.activateListeners = setupMouseManager.bind(token);
        console.log(`pick-up-stix | updateToken hook | itemIds ${flags.itemIds}`);
    }
});
Hooks.on('createToken', async (scene, tokenData, options, userId) => {
    var _a, _b;
    console.log(`pick-up-stix | create token`);
    const token = (_b = (_a = canvas === null || canvas === void 0 ? void 0 : canvas.tokens) === null || _a === void 0 ? void 0 : _a.placeables) === null || _b === void 0 ? void 0 : _b.find((p) => p.id === tokenData._id);
    const flags = token.getFlag('pick-up-stix', 'pick-up-stix');
    if (flags) {
        console.log(`pick-up-stix | createToken | itemIds ${flags.itemIds}`);
        token.activateListeners = setupMouseManager.bind(token);
    }
});
function displayItemContainerApplication(hud, img, tokenData) {
    return async function (ev) {
        var _a, _b;
        console.log(`pick-up-sticks | toggle icon clicked`);
        const token = (_b = (_a = canvas === null || canvas === void 0 ? void 0 : canvas.tokens) === null || _a === void 0 ? void 0 : _a.placeables) === null || _b === void 0 ? void 0 : _b.find((p) => p.id === tokenData._id);
        if (!token) {
            console.log(`pick-up-stix | Couldn't find token '${tokenData._id}'`);
            return;
        }
        const flags = token.getFlag('pick-up-stix', 'pick-up-stix');
        let b = new SelectItemApplication(token);
        b.render(true);
    };
}
function setupMouseManager() {
    console.log(`pick-up-stix | setupMouseManager`);
    const permissions = {
        clickLeft: () => true,
        clickLeft2: this._canView,
        clickRight: this._canHUD,
        clickRight2: this._canConfigure,
        dragStart: this._canDrag
    };
    // Define callback functions for each workflow step
    const callbacks = {
        clickLeft: handleTokenItemClicked,
        clickLeft2: this._onClickLeft2,
        clickRight: this._onClickRight,
        clickRight2: this._onClickRight2,
        dragLeftStart: this._onDragLeftStart,
        dragLeftMove: this._onDragLeftMove,
        dragLeftDrop: this._onDragLeftDrop,
        dragLeftCancel: this._onDragLeftCancel,
        dragRightStart: null,
        dragRightMove: null,
        dragRightDrop: null,
        dragRightCancel: null
    };
    // Define options
    const options = {
        target: this.controlIcon ? "controlIcon" : null
    };
    // Create the interaction manager
    this.mouseInteractionManager = new MouseInteractionManager(this, canvas.stage, permissions, callbacks, options).activate();
}
async function handleTokenItemClicked(e) {
    var _a, _b, _c, _d, _e, _f;
    console.log(`pick-up-stix | handleTokenItemClicked | ${this.id}`);
    // if the token is hidden just do a normal click
    if (e.currentTarget.data.hidden) {
        console.log(`pick-up-stix | handleTokenItemClicked | token is hidden, handle normal click`);
        this._onClickLeft(e);
        return;
    }
    // get the tokens that the user controls
    const controlledTokens = canvas.tokens.controlled;
    // get the flags on the clicked token
    const flags = duplicate(this.getFlag('pick-up-stix', 'pick-up-stix'));
    // gm special stuff
    if (game.user.isGM) {
        if (!controlledTokens.length) {
            console.log(`pick-up-stix | handleTokenItemClicked | no controlled tokens, handle normal click`);
            this._onClickLeft(e);
            return;
        }
        const controlledFlags = controlledTokens[0].getFlag('pick-up-stix', 'pick-up-stix');
        // if there is only one controlled token and it's the item itself, don't do anything
        if (controlledTokens.length === 1 && (controlledTokens.includes(this) || controlledFlags)) {
            console.log(`pick-up-stix | handleTokenItemClicked | only controlling the item, handle normal click`);
            this._onClickLeft(e);
            return;
        }
    }
    if (controlledTokens.length !== 1 || ((_b = (_a = controlledTokens[0]) === null || _a === void 0 ? void 0 : _a.getFlag('pick-up-stix', 'pick-up-stix.itemIds')) === null || _b === void 0 ? void 0 : _b.length) > 0) {
        ui.notifications.error('You must be controlling only one token to pick up an item');
        return;
    }
    // get the token the user is controlling
    const userControlledToken = controlledTokens[0];
    // if the item isn't visible can't pick it up
    if (!this.isVisible) {
        console.log(`pick-up-stix | handleTokenItemClicked | item is not visible to user`);
        return;
    }
    // get the distance to the token and if it's too far then can't pick it up
    const dist = Math.hypot(userControlledToken.x - this.x, userControlledToken.y - this.y);
    const maxDist = Math.hypot(canvas.grid.size, canvas.grid.size);
    if (dist > maxDist) {
        console.log(`pick-up-stix | handleTokenItemClicked | item is out of reach`);
        return;
    }
    const isLocked = flags.isLocked;
    // if it's locked then it can't be opened
    if (isLocked) {
        console.log(`pick-up-stix | handleTokenItemClicked | item is locked, play lock sound`);
        var audio = new Audio('sounds/lock.wav');
        audio.play();
        return;
    }
    // if it's a container and it's open and can't be closed then don't do anything
    if (flags.isContainer && flags.isOpen && !flags.canClose) {
        console.log(`pick-up-stix | handleTokenItemClicked | container is open and can't be closed`);
        return;
    }
    let containerUpdates;
    // create an update for the container but don't run update it yet. if it's container then switch then
    // open property
    if (flags.isContainer) {
        console.log(`pick-up-stix | handleTokenItemClicked | item is a container`);
        flags.isOpen = !flags.isOpen;
        containerUpdates = {
            img: flags.isOpen ? flags.imageContainerOpenPath : flags.imageContainerClosedPath,
            flags: {
                'pick-up-stix': {
                    'pick-up-stix': Object.assign({}, flags)
                }
            }
        };
    }
    // if it's not a container or if it is and it's open it's now open (from switching above) then update
    // the actor's currencies if there are any in the container
    if (!flags.isContainer || flags.isOpen) {
        let currencyFound = false;
        let chatContent = '';
        const userCurrencies = (_e = (_d = (_c = userControlledToken === null || userControlledToken === void 0 ? void 0 : userControlledToken.actor) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.data) === null || _e === void 0 ? void 0 : _e.currency;
        const actorUpdates = (_f = Object.keys((flags === null || flags === void 0 ? void 0 : flags.currency) || {})) === null || _f === void 0 ? void 0 : _f.reduce((acc, next) => {
            var _a, _b, _c, _d;
            if (((_a = flags === null || flags === void 0 ? void 0 : flags.currency) === null || _a === void 0 ? void 0 : _a[next]) > 0) {
                currencyFound = true;
                chatContent += `<span class="pick-up-stix-chat-currency ${next}"></span><span>(${next}) ${(_b = flags === null || flags === void 0 ? void 0 : flags.currency) === null || _b === void 0 ? void 0 : _b[next]}</span><br />`;
                userCurrencies[next] = userCurrencies[next] ? +userCurrencies[next] + +((_c = flags.currency) === null || _c === void 0 ? void 0 : _c[next]) : (_d = flags.currency) === null || _d === void 0 ? void 0 : _d[next];
            }
            return userCurrencies;
        }, userCurrencies);
        if (currencyFound) {
            let content = `<p>Picked up:</p>${chatContent}`;
            ChatMessage.create({
                content,
                speaker: {
                    alias: userControlledToken.actor.name,
                    scene: game.scenes.active.id,
                    actor: userControlledToken.actor.id,
                    token: userControlledToken.id
                }
            });
            await updateActor(userControlledToken.actor, { data: { data: { currency: Object.assign({}, userCurrencies) } } });
        }
    }
    // get the items from teh container and create an update object if there are any
    if (!flags.isContainer || flags.isOpen) {
        const itemsToCreate = [];
        for (let itemData of flags.itemIds) {
            const item = itemData.pack !== undefined ? await game.packs.get(itemData.pack).getEntity(itemData.id) : game.items.get(itemData.id);
            const datas = [];
            for (let i = 0; i < itemData.count; i++) {
                datas.push(Object.assign(Object.assign({}, item.data), { 'flags.pick-up-stix.pick-up-stix.pack': itemData.pack, 'flags.pick-up-stix.pick-up-stix.sourceItemId': itemData.id }));
            }
            itemsToCreate.push(...datas);
            if (itemData.count > 0) {
                ChatMessage.create({
                    content: `
						<p>Picked up ${itemData.count} ${item.name}</p>
						<img src="${item.img}" style="width: 40px;" />
					`,
                    speaker: {
                        alias: userControlledToken.actor.name,
                        scene: game.scenes.active.id,
                        actor: userControlledToken.actor.id,
                        token: userControlledToken.id
                    }
                });
            }
        }
        // if it's a container, clear out the items as they've been picked up now
        if (flags.isContainer) {
            containerUpdates.flags['pick-up-stix']['pick-up-stix'].itemIds = [];
            containerUpdates.flags['pick-up-stix']['pick-up-stix'].currency = { pp: 0, gp: 0, ep: 0, sp: 0, cp: 0 };
        }
        await createOwnedEntity(userControlledToken.actor, itemsToCreate);
    }
    // if there are any container updates then update the container
    if (containerUpdates) {
        await new Promise(resolve => {
            setTimeout(() => {
                updateToken(this, containerUpdates);
                resolve();
            }, 300);
        });
    }
    if (!flags.isContainer) {
        await deleteToken(this);
    }
    this.mouseInteractionManager._deactivateDragEvents();
}
async function deleteToken(token) {
    console.log(`pick-up-stix | deleteToken with args:`);
    console.log(token);
    if (game.user.isGM) {
        await canvas.scene.deleteEmbeddedEntity('Token', token.id);
        return;
    }
    const msg = {
        sender: game.user.id,
        type: SocketMessageType.deleteToken,
        data: token.id
    };
    socket.emit('module.pick-up-stix', msg);
}
async function updateToken(token, updates) {
    console.log(`pick-up-stix | updateToken with args:`);
    console.log(token, updates);
    if (game.user.isGM) {
        await token.update(updates);
        return;
    }
    const msg = {
        sender: game.user.id,
        type: SocketMessageType.updateToken,
        data: {
            tokenId: token.id,
            updates
        }
    };
    socket.emit('module.pick-up-stix', msg);
}
async function updateActor(actor, updates) {
    if (game.user.isGM) {
        await actor.update(updates);
        return;
    }
    const msg = {
        sender: game.user.id,
        type: SocketMessageType.updateActor,
        data: {
            actorId: actor.id,
            updates
        }
    };
    socket.emit('module.pick-up-stix', msg);
}
async function createOwnedEntity(actor, items) {
    if (game.user.isGM) {
        await actor.createEmbeddedEntity('OwnedItem', items);
        return;
    }
    const msg = {
        sender: game.user.id,
        type: SocketMessageType.createOwnedEntity,
        data: {
            actorId: actor.id,
            items
        }
    };
    socket.emit('module.pick-up-stix', msg);
}
/**
 * @override
 *
 * @param event
 */
async function handleOnDrop(event) {
    console.log(`pick-up-stix | handleOnDrop | called with args:`);
    console.log(event);
    event.preventDefault();
    // Try to extract the data
    let data;
    try {
        data = JSON.parse(event.dataTransfer.getData('text/plain'));
    }
    catch (err) {
        return false;
    }
    // Acquire the cursor position transformed to Canvas coordinates
    const [x, y] = [event.clientX, event.clientY];
    const t = this.stage.worldTransform;
    data.x = (x - t.tx) / canvas.stage.scale.x;
    data.y = (y - t.ty) / canvas.stage.scale.y;
    // Dropped Actor
    if (data.type === "Actor")
        canvas.tokens._onDropActorData(event, data);
    // Dropped Journal Entry
    else if (data.type === "JournalEntry")
        canvas.notes._onDropData(event, data);
    // Dropped Macro (clear slot)
    else if (data.type === "Macro") {
        game.user.assignHotbarMacro(null, data.slot);
    }
    // Dropped Tile artwork
    else if (data.type === "Tile") {
        return canvas.tiles._onDropTileData(event, data);
    }
    // Dropped Item
    else if (data.type === "Item") {
        handleDropItem(data);
    }
}
async function handleDropItem(dropData) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    console.log(`pick-up-stix | handleDropItem | called with args:`);
    console.log(dropData);
    // if the item came from an actor's inventory, then it'll have an actorId property, we'll need to remove the item from that actor
    const sourceActorId = dropData.actorId;
    let pack;
    let itemId;
    // if the item comes from an actor's inventory, then the data structure is a tad different, the item data is stored
    // in a data property on the dropData parameter rather than on the top-level of the dropData
    if (sourceActorId) {
        pack = (_d = (_c = (_b = (_a = dropData.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b['pick-up-stix']) === null || _c === void 0 ? void 0 : _c['pick-up-stix']) === null || _d === void 0 ? void 0 : _d.pack;
        itemId = (_h = (_g = (_f = (_e = dropData.data) === null || _e === void 0 ? void 0 : _e.flags) === null || _f === void 0 ? void 0 : _f['pick-up-stix']) === null || _g === void 0 ? void 0 : _g['pick-up-stix']) === null || _h === void 0 ? void 0 : _h.sourceItemId;
    }
    else {
        pack = dropData.pack;
        itemId = dropData.id;
    }
    const item = pack ? await game.packs.get(pack).getEntity(itemId) : game.items.get(itemId);
    if (!item) {
        console.log(`pick-up-stix | handleDropItem | item '${dropData.id}' not found in game items or compendium`);
        return;
    }
    if (sourceActorId) {
        await game.actors.get(sourceActorId).deleteOwnedItem(dropData.data._id);
    }
    let targetToken;
    let p;
    for (p of canvas.tokens.placeables) {
        if (dropData.x < p.x + p.width && dropData.x > p.x && dropData.y < p.y + p.height && dropData.y > p.y && p instanceof Token && p.actor) {
            targetToken = p;
            break;
        }
    }
    if (targetToken) {
        await createOwnedEntity(targetToken.actor, [Object.assign(Object.assign({}, item.data), { 'flags.pick-up-stix.pick-up-stix.pack': pack, 'flags.pick-up-stix.pick-up-stix.sourceItemId': item.id })]);
    }
    else {
        const hg = canvas.dimensions.size / 2;
        dropData.x -= (hg);
        dropData.y -= (hg);
        const { x, y } = canvas.grid.getSnappedPosition(dropData.x, dropData.y, 1);
        dropData.x = x;
        dropData.y = y;
        Token.create({
            img: item.img,
            name: item.name,
            x: dropData.x,
            y: dropData.y,
            disposition: 0,
            flags: {
                'pick-up-stix': {
                    'pick-up-stix': {
                        originalImagePath: item.img,
                        itemIds: [
                            { id: itemId, count: 1, pack }
                        ]
                    }
                }
            }
        });
    }
}
